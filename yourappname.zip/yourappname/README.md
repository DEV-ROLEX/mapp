# yourappname

## 📱 Version 1.8 – To Do
- **[Add]** Upgrade flutter version to 3.35.0
- **[Add]** Route use
- **[Add]** Deeplink support for Web
- **[Add]** Portrait Web Series (Shorts Style)
- **[Add]** VDOCipher DRM for secure video streaming
- **[Add]** Auto Next Episode Play  
- **[Add]** Default fullscreen video player (Web)
- **[Add]** Keyboard D-pad navigation for Web (Desktop)
- **[Add]** Prevented Right-click on Web to protect video URLs
- **[Add]** Web version add banner dot & section side arrow for left right move
- **[Improve]** Optimized overall performance and code quality
- **[Improve]** Web design & footer layout Improved
- **[BugFixed]** Update Razorpay PG code and add Create Order API  
- **[BugFixed]** Add PayUMoney payment geateway with latest version
- **[BugFixed]** Fix FFmpeg issue  
- **[BugFixed]** Fix Vimeo player issue  

---

## 🗓 Version 1.7 – 07 May 2025
- **[Add]** Rent video expired time show on app  
- **[Add]** Upcoming subscription purchase  
- **[Add]** Google IMA ads show on player  
- **[Add]** Picture-in-Picture mode (Android & iOS)  
- **[Add]** Deeplinking (Android & iOS)  
- **[Add]** Multiple video qualities  
- **[Add]** Multiple subtitles with toggle feature  
- **[Add]** AWS S3 integration  
- **[Design]** New design for Home, Search & Settings  
- **[Design]** New pages & design for Web  
- **[BugFixed]** Subtitle not visible in Android & Web  
- **[BugFixed]** Parental control management issue  
- **[BugFixed]** Activate TV & OTP Verify page dialog issue  
- **[BugFixed]** Manage Top 10 in ViewAll page  
- **[BugFixed]** Switch Kids profile to main profile password issue  

---

## 🗓 Version 1.6 – 07 Sept 2024
- Eye-catching full app & web design  
- Kids Profile  
- Parental Control  
- Producer separate panel  
- Admin Panel redesign  
- Dynamic Menu hide/show  
- TMDB integration added  
- Multiple Device Sync  
- Offline Download (Apps only)  
- Multi-language support  
- ChromeCast & AirPlay support (Apps only)  
- Clear Database  
- Command Header on Web Details page  
- Subscription Package (Web)  
- Transaction History (Web)  
- Activate TV from Web  
- Edit Profile (Web)  
- Minor Bugs Fixed  

---

## 🗓 Version 1.5 – 15 Sept 2023
- **[Add]** Multiple languages  
- **[Add]** Instamojo Payment Gateway  
- **[Add]** Paystack Payment Gateway  
- **[Add]** PayU Payment Gateway  
- **[Add]** Flutterwave Payment Gateway  
- **[Fix]** Multiple video quality bug  
- **[Fix]** Minor bugs  

---

## 🗓 Version 1.4 – 13 August 2023
- **[Add]** Video Player  
- **[Fix]** M3U8 link playback  
- **[Fix]** Admob issues  
- **[Fix]** Minor bugs  

---

## 🗓 Version 1.3 – 05 July 2023
- **[Add]** Video Player  
- **[Fix]** M3U8 link playback  
- **[Fix]** Admob issues  
- **[Fix]** Minor bugs  

---

## 🗓 Version 1.2 – 26 June 2023
- **[Add]** Upcoming Movies Section  
- **[Add]** Upcoming TV Show / Web Series Section  
- **[Add]** Cash Payment Method  
- **[Add]** Stripe Payment Gateway  
- **[Add]** PayPal Payment Gateway  
- **[Add]** Paytm Payment Gateway  
- **[Add]** YouTube Link for Trailer Play  
- **[Add]** Activate TV from App  
- **[Add]** Social Link management from Admin panel  
- **[Fix]** Flutter 3.10.5 support  
- **[Fix]** Minor bugs  

---

## 🗓 Version 1.1 – 30 May 2023
- IMDB key dynamically added  
- Auto play trailer on Details Page  
- YouTube external URL type added for Trailer  
- Flutter 3.7.9 updated  
- Minor bugs fixed  

---

## 🗓 Version 1.0 – 28 March 2023
- **Initial Release**
